package com.example.wsbapp3.interfaces;

public interface BusStopsFragmentInterface {
    void onChildItemClick(int parentPosition, int childPosition, String item);
}
