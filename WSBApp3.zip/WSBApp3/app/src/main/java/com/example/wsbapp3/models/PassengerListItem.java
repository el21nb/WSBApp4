package com.example.wsbapp3.models;

/**
 * Model class representing a list item in the recyclerview passenger list in PassengersFragment
 */
public class PassengerListItem {

    private String[] childInfo;

    private String child;

    /**
     * Default constructor
     */
    public PassengerListItem() {

    }
}
